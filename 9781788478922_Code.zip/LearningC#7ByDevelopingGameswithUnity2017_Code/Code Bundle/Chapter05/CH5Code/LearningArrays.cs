﻿using UnityEngine;
using System.Collections;

public class LearningArrays : MonoBehaviour {


	public string student1 = "Greg";
	public string student2 = "Kate";
	public string student3 = "Adam";
	public string student4 = "Mia";


	public string[] students = new string[]{"Greg", "Kate", "Adam", "Mia"};


	public string[] myArrayName = new string[4];

}
